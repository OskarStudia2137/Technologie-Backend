Jak uruchomić?

1. Zainstaluj zależności(np. poprzez terminal w VisualStudio Code):
   ```bash
   pip install -r requirements.txt